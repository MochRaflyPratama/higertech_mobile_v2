import 'package:flutter/material.dart';

class getCurrentLocation extends StatefulWidget {
  const getCurrentLocation({super.key});

  @override
  State<getCurrentLocation> createState() => _getCurrentLocationState();
}

class _getCurrentLocationState extends State<getCurrentLocation> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}